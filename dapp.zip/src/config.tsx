/* eslint-disable prettier/prettier */
export const contractAddress =
  'erd1qqqqqqqqqqqqqpgqagkxackseqfwykugfyn4czsktp3tdnvqj0wq820q7r';

export const dAppName = 'TIGER\'S PARTY CLUB';
export const mode = 'devnet-';
export const nft1= 'ULBS-c22d32';
export const nft2='FACES-dd0aec';